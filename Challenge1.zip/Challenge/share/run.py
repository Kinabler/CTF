import json
from subprocess import check_output, STDOUT
from flask import Flask, render_template, request
import subprocess

app = Flask(__name__)

@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        return render_template('login.html')
    elif request.method == 'POST':
        try:
            result = check_output(['/app/bin/login', request.form.get('username'), request.form.get('password')], stderr=STDOUT)
            if b"Read Flag" in result:
                output = subprocess.check_output(['cat', './root.txt'])
            elif b"Welcome" in result:
                output = b'Hi Hacker! Welcome to EHC\n Do you want to do anything else?'
            else:
                output = b'You have not registered for an EHC account'
        except Exception as e:
            output = b'Something went wrong: {}' + (str(e).encode())

        try:
            output = output.decode()  # Try decoding the output
        except AttributeError:
            # If it's already a string, leave it as is
            pass

        return render_template('login.html', output=output)


if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=False)

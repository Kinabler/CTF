#!/bin/sh

docker build . -t webpwntest
docker run --rm -v .:/src -p 5001:5000 -it webpwntest